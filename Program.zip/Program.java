import java.util.ArrayList;
import java.util.*;

public class Program {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //int rows = scanner.nextInt();
        String[] ko = new String[10];
        ArrayList<Character> n = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            String rows = scanner.nextLine();

            ko[i] = rows.toUpperCase();
        }
        for (int i = 0; i < 10; i++) {
            char l = ko[i].charAt(ko[i].length()-1);
            n.add(l);



        }
        //String ho =  new String(n);
        //String no = n.toString().toUpperCase();
        Collections.reverse(n);
        for(char i : n){
           char bn = i;
            System.out.print(bn);

        }
        //System.out.println(no);
    }
}
